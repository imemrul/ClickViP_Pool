<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Deal_contact_person extends Model
{
    //
}
