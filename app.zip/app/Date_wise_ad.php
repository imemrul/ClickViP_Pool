<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Date_wise_ad extends Model
{
    protected $fillable = ['shop_id','ad_id','ibs','date'];
}
