<?php

namespace App\Http\Controllers;

use App\Slider;
use Illuminate\Http\Request;

class SliderController extends Controller
{
    public function __construct(){
        $this->middleware('RedirectIfNotAuthenticate');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $sliders = Slider::paginate('10');
        return view('admin.modules.slider.index',compact('sliders'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.modules.slider.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // dd($request->file('image'));
        $data = $request->all();
        if($file = $request->hasFile('image')) {
            $file = $request->file('image') ;
            $fileName = $file->getClientOriginalName() ;
            $destinationPath = public_path().'/uploads/slider' ;
            $file->move($destinationPath,$fileName);
            $data['slide_image'] = 'uploads/slider/'.$fileName;
            $data['activeTo'] = "2222-01-02";
            $slider = Slider::create($data);
            return redirect()->back();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Slider  $slider
     * @return \Illuminate\Http\Response
     */
    public function show(Slider $slider)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Slider  $slider
     * @return \Illuminate\Http\Response
     */
    public function edit(Slider $slider)
    {
        $slide = Slider::find($slider)->first();
        return view('admin.modules.slider.edit',compact('slide'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Slider  $slider
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // dd($request->all());
        $slide = Slider::find($id);
        $data = $request->all();
        if($request->hasFile('slide_image')){
            if(file_exists('public/'.$slide->slide_image)){
            unlink('public/'.$slide->slide_image);
            }
            $file = $request->file('slide_image') ;
            $fileName = $file->getClientOriginalName() ;
            $destinationPath = public_path().'/uploads/slider' ;
            $file->move($destinationPath,$fileName);
            $data['slide_image'] = 'uploads/slider/'.$fileName;
        }
        $slide->fill($data)->save();
        return redirect()->back()->with('message','Slider Updated...');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Slider  $slider
     * @return \Illuminate\Http\Response
     */
    public function destroy(Slider $slider)
    {
        //
    }
}
