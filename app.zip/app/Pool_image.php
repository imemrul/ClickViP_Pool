<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pool_image extends Model
{
    protected $fillable = ['pool_id','name'];
}
