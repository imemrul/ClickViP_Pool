<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Deal_executive extends Model
{
    //
}
