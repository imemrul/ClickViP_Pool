<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pool_facility extends Model
{
    protected $fillable = ['pool_id','booking_id','facility_id'];
}
